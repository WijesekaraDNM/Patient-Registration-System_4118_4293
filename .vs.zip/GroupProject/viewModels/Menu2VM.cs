﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace GroupProject.viewModels
{
    public partial class Menu2VM:ObservableObject
    {
        [ObservableProperty]
        public int? pID;

        [ObservableProperty]
        public string? pName;

        [ObservableProperty]
        public int pAge;

        [ObservableProperty]
        public string? pTNum;

        [ObservableProperty]
        public string? pDate;

        [ObservableProperty]
        public string? pAddress;

        [ObservableProperty]
        public string? pGuard;

        [ObservableProperty]
        public string? pGTeleNum;

        [ObservableProperty]
        public string? pGender;

        [RelayCommand]
        public void insertPatient()
        {
            Patient patient = new Patient()
            {
                Id = (int)pID,
                Name = pName,
                TeleNumber = pTNum,
                Age = pAge,
                Address = pAddress,
                Guardian = pGuard,
                GuardianTeleNum = pGTeleNum,
                AdmittedDate = pDate,
                Gender = pGender,
                PatientType = "Not Given",
                WardNo = "Not Given"
            };


            using (var dbP = new patientContext())
            {
                dbP.Patients.Add(patient);
                dbP.SaveChanges();
            }

            MessageBoxResult insertResult = MessageBox.Show("Resistration Successful");
        }
    }
}
