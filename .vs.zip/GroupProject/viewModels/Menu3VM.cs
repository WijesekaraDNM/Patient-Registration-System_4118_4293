﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GroupProject.viewModels
{
    public partial class Menu3VM:ObservableObject
    {
        [ObservableProperty]
        public int? pID;

        [ObservableProperty]
        public string? pName;

        [ObservableProperty]
        public int pAge;

        [ObservableProperty]
        public string? pTNum;

        [ObservableProperty]
        public string? pDate;

        [ObservableProperty]
        public string? pAddress;

        [ObservableProperty]
        public string? pGuard;

        [ObservableProperty]
        public string? pGTeleNum;

        [ObservableProperty]
        public string? pGender;

        [ObservableProperty]
        public string? pWNo;

        [ObservableProperty]
        public string? pDoctor;

        [ObservableProperty]
        public string? pInComName;

        [ObservableProperty]
        public string? pInComNum;
        [ObservableProperty]
        public string? pInPolicy;
        [ObservableProperty]
        public string? pInGroup;
        [ObservableProperty]
        public string? pInRelation;
        [ObservableProperty]
        public string? pInName;

        [RelayCommand]
        public void insertPatient()
        {
            Patient patient = new Patient()
            {
                Id = (int)pID,
                Name = pName,
                TeleNumber = pTNum,
                Age = pAge,
                Address = pAddress,
                Guardian = pGuard,
                GuardianTeleNum = pGTeleNum,
                AdmittedDate = pDate,
                Gender = pGender,
                WardNo = pWNo,
                Doctor=pDoctor,
                InsuredName=pInName,
                InsuaranceCom=pInComName,
                InsuranceComeNum=pInComNum,
                InsuranceGroup = pInGroup,
                InsurancePolicy=pInPolicy,
                InsuranceRelation=pInRelation,

            };


            using (var dbP = new patientContext())
            {
                dbP.Patients.Add(patient);
                dbP.SaveChanges();
            }

            MessageBoxResult insertResult = MessageBox.Show("Resistration Successful");
        }
    }
}
