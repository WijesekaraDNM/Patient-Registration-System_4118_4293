﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GroupProject
{
    public partial class MainWindowVM:ObservableObject
    {

        [ObservableProperty]
        public string? usName;

        [ObservableProperty]
        public string? passWord;

        [RelayCommand]

        public void verifyUser()
        {
            using (var db = new UserContext())
            {
                bool userFound = db.Users.Any(User => User.userName == usName && User.password == passWord); // verify user and password exist

                if (userFound)
                {

                    var newWindow = new SecondWindow();
                    newWindow.Show();
                }
                else
                {
                    MessageBoxResult resultFind = MessageBox.Show("User Not Found");
                }

            }
        }
    }
}

