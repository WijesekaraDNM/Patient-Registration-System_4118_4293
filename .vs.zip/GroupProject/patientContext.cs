﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject
{
    public class patientContext:DbContext
    {
        private readonly string path = @"\F:\Academic\3rd sem\sem3\GUI programing\Assignment\GroupProject\DataBase\Patient.db";

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            =>optionsBuilder.UseSqlite($"Data Source={path}");

        public DbSet<Patient> Patients { get; set; }
    }
}
