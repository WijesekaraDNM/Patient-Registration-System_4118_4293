﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject
{
    public class Patient
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public string TeleNumber { get; set; }
        public string AdmittedDate { get; set; }
        public string Gender { get; set; }
        public string Guardian { get; set; }
        public string PatientType { get; set; }
        public string WardNo { get; set; }
        public int payments { get; set; }
        public string? GuardianTeleNum { get; internal set; }
        public string? Doctor { get; internal set; }
        public string? InsuredName { get; internal set; }
        public string? InsuaranceCom { get; internal set; }
        public string? InsuranceComeNum { get; internal set; }
        public string? InsurancePolicy { get; internal set; }
        public string? InsuranceRelation { get; internal set; }
        public string? InsuranceGroup { get; internal set; }
    }
}
