﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject
{
    public class UserContext:DbContext
    {
        private readonly string path = @"F:\Academic\3rd sem\sem3\GUI programing\Assignment\GroupProject\DataBase\User.db";

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            => optionsBuilder.UseSqlite($"Data Source={path}");

        public DbSet<User> Users { get; set; }
    }
}
